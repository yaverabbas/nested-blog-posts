Translations for this plugin are managed at https://translate.wordpress.org.
