# License

This plugin is licensed under the GNU General Public License v2 or later.

See: https://www.gnu.org/licenses/gpl-2.0.html
